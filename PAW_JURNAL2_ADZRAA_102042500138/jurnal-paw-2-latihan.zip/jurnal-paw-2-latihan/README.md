# LMS Praktikum (PAW Modul 2)

Aplikasi web Learning Management System sederhana berbasis PHP native, HTML, CSS murni, dan MySQL/MariaDB. Aplikasi mengelola mata kuliah, materi, dan tugas. Satu mata kuliah memiliki banyak materi dan banyak tugas (relasi 1 ke N).

Berkas `README.txt` adalah instruksi tugas dari berkas awal dan sengaja dibiarkan. Dokumentasi proyek ada di berkas ini.

## Persyaratan

- PHP 8.1 atau lebih baru dengan ekstensi `mysqli` dan `mbstring`
- MySQL 8.0.16+ atau MariaDB 10.2+ (batasan `CHECK` baru ditegakkan mulai versi ini; di versi lebih lama validasi tetap dijaga oleh PHP)
- XAMPP, Laragon, MAMP, atau server bawaan PHP

## Struktur direktori

```
jurnal-paw-2-latihan/
├── README.md          Dokumentasi proyek (berkas ini)
├── README.txt         Instruksi tugas dari berkas awal
├── skema_lms.sql      Skema database + data contoh (disarankan)
├── database.sql       Skema versi berkas awal (tetap bisa dipakai)
├── connect.php        Koneksi mysqli
├── functions.php      Fungsi bantu, validasi, token sesi
├── header.php         Kerangka HTML bagian atas + pesan notifikasi
├── footer.php         Kerangka HTML bagian bawah
├── index.php          Beranda: ringkasan angka dari database
├── mata_kuliah.php    CRUD mata kuliah
├── materi.php         CRUD materi
├── tugas.php          CRUD tugas
└── styles.css         CSS murni, responsif
```

## Menyiapkan database

1. Nyalakan MySQL/MariaDB.
2. Import `skema_lms.sql` lewat phpMyAdmin (tab Import), atau lewat terminal:

   ```
   mysql -u root -p < skema_lms.sql
   ```

3. Buka `connect.php`, sesuaikan `$port`, `$user`, dan `$pass`. XAMPP/Laragon biasanya port 3306 dengan password kosong. MAMP biasanya port 8889 dengan password `root`.
4. Taruh folder proyek di `htdocs` (XAMPP) atau `www` (Laragon), lalu buka `http://localhost/jurnal-paw-2-latihan/`.
   Tanpa Apache, jalankan dari dalam folder proyek:

   ```
   php -S 127.0.0.1:8080
   ```

   lalu buka `http://127.0.0.1:8080`.

Import ulang aman karena data contoh memakai `INSERT IGNORE`.

### Skema database (`skema_lms.sql`)

```sql
CREATE DATABASE IF NOT EXISTS paw_jurnal2_lms CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE paw_jurnal2_lms;

CREATE TABLE IF NOT EXISTS mata_kuliah (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    kode VARCHAR(20) NOT NULL,
    nama VARCHAR(100) NOT NULL,
    dosen VARCHAR(100) NOT NULL,
    semester TINYINT UNSIGNED NOT NULL,
    CONSTRAINT uq_mata_kuliah_kode UNIQUE (kode),
    CONSTRAINT ck_mata_kuliah_kode CHECK (CHAR_LENGTH(kode) >= 3),
    CONSTRAINT ck_mata_kuliah_nama CHECK (CHAR_LENGTH(nama) >= 3),
    CONSTRAINT ck_mata_kuliah_dosen CHECK (CHAR_LENGTH(dosen) >= 3),
    CONSTRAINT ck_mata_kuliah_semester CHECK (semester BETWEEN 1 AND 14)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS materi (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    mata_kuliah_id INT UNSIGNED NOT NULL,
    judul VARCHAR(150) NOT NULL,
    isi TEXT NOT NULL,
    tautan VARCHAR(255) NOT NULL,
    CONSTRAINT fk_materi_mata_kuliah FOREIGN KEY (mata_kuliah_id)
        REFERENCES mata_kuliah (id) ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT ck_materi_judul CHECK (CHAR_LENGTH(judul) >= 3),
    CONSTRAINT ck_materi_isi CHECK (CHAR_LENGTH(isi) BETWEEN 3 AND 2000),
    CONSTRAINT ck_materi_tautan CHECK (tautan LIKE 'http://%' OR tautan LIKE 'https://%')
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS tugas (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    mata_kuliah_id INT UNSIGNED NOT NULL,
    judul VARCHAR(150) NOT NULL,
    instruksi TEXT NOT NULL,
    tenggat DATE NOT NULL,
    status ENUM('Draf', 'Aktif', 'Selesai') NOT NULL DEFAULT 'Draf',
    CONSTRAINT fk_tugas_mata_kuliah FOREIGN KEY (mata_kuliah_id)
        REFERENCES mata_kuliah (id) ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT ck_tugas_judul CHECK (CHAR_LENGTH(judul) >= 3),
    CONSTRAINT ck_tugas_instruksi CHECK (CHAR_LENGTH(instruksi) BETWEEN 3 AND 2000),
    KEY idx_tugas_tenggat (tenggat)
) ENGINE=InnoDB;

INSERT IGNORE INTO mata_kuliah (id, kode, nama, dosen, semester) VALUES
(1, 'PAW-101', 'Pengembangan Aplikasi Website', 'Dosen PAW', 3),
(2, 'ALP-101', 'Algoritma dan Pemrograman', 'Dosen ALP', 1);

INSERT IGNORE INTO materi (id, mata_kuliah_id, judul, isi, tautan) VALUES
(1, 1, 'Operasi CRUD PHP dan MySQL', 'Pelajari penambahan, pembacaan, perubahan, dan penghapusan data melalui PHP.', 'https://www.php.net/manual/en/book.mysqli.php'),
(2, 2, 'Percabangan dan Perulangan', 'Gunakan kondisi dan perulangan untuk mengolah data dalam program.', 'https://www.php.net/manual/en/language.control-structures.php');

INSERT IGNORE INTO tugas (id, mata_kuliah_id, judul, instruksi, tenggat, status) VALUES
(1, 1, 'Membangun LMS sederhana', 'Bangun pengelolaan mata kuliah, materi, dan tugas dengan operasi CRUD yang dapat diuji.', '2026-11-01', 'Aktif'),
(2, 2, 'Latihan percabangan', 'Buat program pemilihan kondisi dan dokumentasikan contoh masukannya.', '2026-11-03', 'Draf');
```

Poin penting skema:

- `ON DELETE RESTRICT` pada kedua kunci asing membuat database menolak penghapusan mata kuliah yang masih punya materi atau tugas.
- `kode` bersifat `UNIQUE`, sehingga kode ganda ditolak di level database juga.
- Aturan format kode (huruf besar, angka, tanda `-`) tidak dipasang sebagai `CHECK` karena `REGEXP` pada kolom `utf8mb4_unicode_ci` tidak membedakan huruf besar dan kecil. Aturan itu dijaga oleh PHP.

## Aturan validasi data

| Entitas | Kolom | Aturan |
|---|---|---|
| Mata kuliah | kode | 3 sampai 20 karakter, unik, hanya huruf besar, angka, dan `-` (input otomatis diubah ke huruf besar) |
| | nama | 3 sampai 100 karakter |
| | dosen | 3 sampai 100 karakter |
| | semester | bilangan bulat 1 sampai 14 |
| Materi | mata_kuliah_id | harus salah satu mata kuliah yang ada |
| | judul | 3 sampai 150 karakter |
| | isi | 3 sampai 2000 karakter |
| | tautan | maksimal 255 karakter, URL valid yang diawali `http://` atau `https://` |
| Tugas | mata_kuliah_id | harus salah satu mata kuliah yang ada |
| | judul | 3 sampai 150 karakter |
| | instruksi | 3 sampai 2000 karakter |
| | tenggat | tanggal valid format `YYYY-MM-DD` (diperiksa dengan `checkdate`) |
| | status | salah satu dari `Draf`, `Aktif`, `Selesai` |

## Alur aplikasi

### Pembagian halaman

Setiap jenis data punya satu berkas (`mata_kuliah.php`, `materi.php`, `tugas.php`). Satu berkas melayani lima tampilan yang dibedakan lewat parameter `?aksi=`:

| URL | Tampilan |
|---|---|
| `materi.php` | daftar, pencarian, filter |
| `materi.php?aksi=tambah` | form tambah |
| `materi.php?aksi=detail&id=1` | detail |
| `materi.php?aksi=edit&id=1` | form edit |
| `materi.php?aksi=hapus&id=1` | halaman konfirmasi hapus |

Pada setiap berkas, bagian PHP di atas mengurus data (ambil, validasi, simpan) dan bagian HTML di bawah mengurus tampilan. `header.php` dan `footer.php` dipanggil dengan `require`.

### Alur tambah dan edit

1. Halaman dibuka lewat GET dan menampilkan form kosong (tambah) atau berisi data lama (edit).
2. Form dikirim lewat POST. Nilai dibersihkan oleh `input()` lalu dicek oleh fungsi `validasi_*`.
3. Jika ada kesalahan, form tampil ulang dengan isian tetap, pesan di bawah kolom yang salah, dan alert merah di atas form.
4. Jika valid, data disimpan dengan prepared statement, lalu `pindah_halaman()` mengalihkan pengguna sambil menitipkan pesan sukses.

### Alur hapus

1. Link Hapus di halaman detail hanya membuka halaman konfirmasi lewat GET. Tidak ada data yang berubah.
2. Tombol "Ya, hapus" mengirim POST beserta token sesi tersembunyi.
3. Server menolak jika metode bukan POST atau token tidak cocok (alert "Token keamanan tidak valid").
4. Khusus mata kuliah, server menghitung materi dan tugas terkait terlebih dulu. Jika ada, penghapusan ditolak dengan alert yang menyebut jumlahnya, disertai tombol menuju daftar materi dan tugas yang sudah terfilter. Jika database tetap menolak (lapisan kedua lewat `ON DELETE RESTRICT`), alert pembatasan relasi tampil.

### Pencarian dan filter

- Mata kuliah: kolom pencarian mencocokkan kode, nama, atau dosen.
- Materi: pencarian mencocokkan judul materi atau nama mata kuliah, digabung dengan filter mata kuliah.
- Tugas: pencarian yang sama, digabung dengan filter mata kuliah dan filter status.
- Kondisi `WHERE` disusun dinamis hanya dari potongan SQL tetap, sedangkan semua nilai dikirim lewat `bind_param()`.
- Jika hasil kosong dan ada filter aktif, tampil pesan "tidak ada yang cocok" dengan tombol **Reset pencarian**. Jika tabel memang kosong, tampil pesan "belum ada data" dengan tombol tambah.

### Pesan notifikasi

`pindah_halaman($tujuan, $pesan, $jenis)` menyimpan pesan di `$_SESSION`. `header.php` menampilkannya satu kali lalu menghapusnya. Jenis `sukses` tampil hijau (`role="status"`), jenis `galat` tampil merah (`role="alert"`).

## Penjelasan fungsi (`functions.php`)

| Fungsi | Kegunaan |
|---|---|
| `h($teks)` | `htmlspecialchars` dengan `ENT_QUOTES` dan UTF-8. Wajib dipakai setiap mencetak data ke HTML. |
| `input($sumber, $nama)` | Mengambil nilai string dari `$_GET` atau `$_POST`, memangkas spasi, dan menyeragamkan baris baru menjadi `\n` agar hitungan panjang teks konsisten. |
| `angka_id($nilai)` | Mengubah teks menjadi ID bilangan bulat positif. Selain angka murni, hasilnya `0`. |
| `escape_like($teks)` | Memberi escape pada `%`, `_`, dan `\` supaya dibaca apa adanya dalam `LIKE`. |
| `pindah_halaman(...)` | Redirect dengan pesan opsional dan jenis pesan. |
| `pilihan_mata_kuliah($conn)` | Daftar `id => "KODE - Nama"` untuk dropdown dan validasi ID. |
| `cari_mata_kuliah`, `cari_materi`, `cari_tugas` | Ambil satu baris berdasarkan ID. Materi dan tugas memakai JOIN agar kode dan nama mata kuliah ikut terambil (`kode_mk`, `nama_mk`). |
| `kode_sudah_dipakai(...)` | Cek keunikan kode, mengabaikan baris yang sedang diedit. |
| `validasi_mata_kuliah`, `validasi_materi`, `validasi_tugas` | Mengembalikan array pesan kesalahan. Array kosong berarti data valid. |
| `token_csrf()` | Membuat dan menyimpan token acak 64 karakter heksadesimal di sesi. |
| `bidang_token()` | Mencetak input tersembunyi berisi token untuk form hapus. |
| `token_valid()` | Membandingkan token kiriman dengan token sesi memakai `hash_equals`. |
| `hitung_milik_mata_kuliah(...)` | Menghitung materi atau tugas milik satu mata kuliah (nama tabel dibatasi daftar putih). |

## Penjelasan query per bagian tugas

| TODO | Berkas | Isi |
|---|---|---|
| 1 | `index.php` | Tiga `COUNT(*)` untuk mata kuliah, materi, tugas, dan satu `COUNT(*)` bertanda `status = ?` untuk tugas aktif. |
| 2 | `materi.php` | `SELECT` dengan `JOIN mata_kuliah`, urut kode mata kuliah lalu judul, filter dinamis. |
| 3 | `materi.php` | `INSERT INTO materi` dengan `bind_param('isss', ...)`. |
| 4 | `materi.php` | `UPDATE materi ... WHERE id = ?` dengan `bind_param('isssi', ...)`. |
| 5 | `materi.php` | `DELETE FROM materi WHERE id = ?` setelah metode POST dan token lolos. |
| 6 | `tugas.php` | `SELECT` dengan `JOIN`, urut tenggat terdekat, tiga filter yang bisa digabung. |
| 7 | `tugas.php` | `INSERT INTO tugas` dengan `bind_param('issss', ...)`. |
| 8 | `tugas.php` | `UPDATE tugas ... WHERE id = ?` dengan `bind_param('issssi', ...)`. |
| 9 | `tugas.php` | `DELETE FROM tugas WHERE id = ?` setelah metode POST dan token lolos. |
| 10 | `mata_kuliah.php` | Hitung materi dan tugas milik mata kuliah, tolak hapus jika salah satunya lebih dari nol. |

Catatan: contoh bawaan di `mata_kuliah.php` dan `functions.php` memakai `execute([...])` (gaya PHP 8.1). Seluruh query yang ditambahkan memakai `prepare()` dan `bind_param()`. Keduanya sama-sama prepared statement.

## Keamanan

- Semua query yang membawa nilai dari pengguna memakai prepared statement.
- ID dari URL divalidasi dengan `angka_id()`, ID dari form dicocokkan dengan daftar mata kuliah yang ada, status dicocokkan dengan daftar status.
- Semua keluaran ke HTML melewati `h()`. Isi multibaris memakai `nl2br(h(...))`.
- Penghapusan hanya berjalan lewat POST dengan token sesi.
- Kesalahan database ditangkap (`mysqli_sql_exception`) dan diganti pesan ramah, tanpa membocorkan detail query.

## Skenario uji

| No | Skenario | Hasil yang diharapkan |
|---|---|---|
| 1 | Buka beranda setelah import data contoh | 2 mata kuliah, 2 materi, 2 tugas, 1 tugas aktif |
| 2 | Tambah mata kuliah dengan kode `paw-202` | Tersimpan sebagai `PAW-202`, alert sukses hijau |
| 3 | Tambah mata kuliah dengan kode `PAW-101` | Ditolak, pesan "Kode mata kuliah sudah digunakan." |
| 4 | Kode `AB`, atau `PAW_101`, atau 21 karakter | Ditolak, pesan format kode |
| 5 | Nama atau dosen 2 karakter, semester `0` atau `15` | Ditolak dengan pesan di bawah kolom masing-masing |
| 6 | Tambah materi dengan tautan `ftp://contoh.com` atau `www.contoh.com` | Ditolak, pesan format tautan |
| 7 | Tambah materi dengan isi 2001 karakter (lewati batas browser lewat inspect element) | Ditolak, "Isi materi harus 3 sampai 2000 karakter." |
| 8 | Tambah tugas dengan tenggat `2026-02-30` | Ditolak, "Tenggat harus tanggal yang valid." |
| 9 | Ubah `value` status di inspect element menjadi `Lainnya` lalu kirim | Ditolak, "Pilih status yang tersedia." |
| 10 | Cari `crud` di materi | 1 data. Filter ALP-101 saja juga 1 data. |
| 11 | Cari `crud` dengan filter ALP-101 | Kosong, tampil pesan tidak ada yang cocok dan tombol Reset pencarian; tombol itu mengembalikan seluruh daftar |
| 12 | Daftar tugas tanpa filter | Urut tenggat terdekat. Filter status `Draf` memunculkan 1 data. |
| 13 | Cari `%` atau `_` di materi | Dibaca apa adanya, hasil kosong (tidak mencocokkan semua baris) |
| 14 | Isi kolom pencarian dengan `'` | Halaman tidak error |
| 15 | Edit materi dan pindahkan ke mata kuliah lain | Daftar menampilkan kode dan nama mata kuliah baru; data lain tidak berubah |
| 16 | Hapus materi lewat halaman konfirmasi | Data hilang, alert sukses |
| 17 | Hapus mata kuliah `PAW-101` | Ditolak dengan alert yang menyebut jumlah materi dan tugasnya |
| 18 | Hapus semua materi dan tugas milik satu mata kuliah, lalu hapus mata kuliahnya | Berhasil |
| 19 | Buat mata kuliah baru tanpa materi atau tugas, lalu hapus | Berhasil |
| 20 | Buka `materi.php?aksi=hapus&id=1` langsung lewat URL | Hanya halaman konfirmasi, tidak ada data terhapus |
| 21 | Kirim form hapus dengan token diubah atau dihapus (inspect element) | Ditolak, alert "Token keamanan tidak valid" |
| 22 | Buka `materi.php?aksi=detail&id=999` atau `id=abc` | Kembali ke daftar dengan alert merah "Materi tidak ditemukan." |
| 23 | Coba sisipkan `<script>alert(1)</script>` sebagai judul | Tampil sebagai teks biasa, skrip tidak berjalan |
| 24 | Perkecil jendela ke lebar HP | Tanpa gulir horizontal, tombol setinggi minimal 44px |
| 25 | Navigasi hanya dengan keyboard (Tab, Enter) | Semua tautan dan tombol terjangkau, fokus terlihat jelas |

## Ringkasan perubahan terhadap berkas awal

- Seluruh komentar dan TODO di berkas awal dibiarkan di tempatnya.
- `functions.php`: validasi diperketat sesuai batas panjang, ditambah fungsi bantu baru, `pindah_halaman` menerima jenis pesan.
- `index.php`, `materi.php`, `tugas.php`, `mata_kuliah.php`: TODO 1 sampai 10 dikerjakan, form hapus memakai token, empty state diberi tombol reset.
- `header.php` dan `styles.css`: alert sukses dan galat dibedakan, warna placeholder digelapkan agar lolos kontras WCAG AA, target sentuh minimal 44px di layar kecil.
- `skema_lms.sql` dan `README.md` ditambahkan.
